from os import name
from setuptools import setup, find_packages

setup(
    name = "DemoMLOPS",
    version = "0.0.1",
    description = "Its Sample",
    author = "Mani",
    license = "MIT",
    packages = find_packages()
)